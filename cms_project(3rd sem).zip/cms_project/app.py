from flask import Flask, render_template, redirect, url_for, request, session
import mysql.connector
from werkzeug.security import generate_password_hash, check_password_hash
from flask import flash, redirect

from datetime import date

app = Flask(__name__)

# Secret key for session management
app.secret_key = 'your_secret_key'  # This key can be any random string

# MySQL Connection
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",  # Add your MySQL password if needed
    database="cms_db"
)


cursor = db.cursor()

# Home Route
@app.route('/')
def home():
    return render_template('home.html')

# Student Login Route
@app.route('/student-login', methods=['GET', 'POST'])
def student_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Query to check if the student exists
        cursor.execute("SELECT * FROM students WHERE username=%s AND password=%s", (username, password))
        student = cursor.fetchone()

        if student:
            session['role'] = 'student'  # Set role as student
            return redirect(url_for('student_dashboard'))
        else:
            return "Invalid username or password"

    return render_template('student_login.html')

# Teacher Login Route
# Teacher Login Route
@app.route('/teacher-login', methods=['GET', 'POST'])
def teacher_login():
    if request.method == 'POST':
        username = request.form['username'].strip()
        password = request.form['password'].strip()

        # Query to check if the teacher exists
        cursor.execute("SELECT id FROM teachers WHERE username=%s AND password=%s", (username, password))
        teacher = cursor.fetchone()

        if teacher:
            session['role'] = 'teacher'  # Set role as teacher
            session['teacher_id'] = teacher[0]  # Store teacher ID in session for later use
            print(f"Logged in teacher ID: {teacher[0]}")  # Log the teacher ID
            return redirect(url_for('teacher_dashboard'))
        else:
            return 'Invalid credentials. Please try again.'

    return render_template('teacher_login.html')

# Admin Login Route
# Admin Login Route
@app.route('/admin-login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Query to check if the admin exists
        cursor.execute("SELECT * FROM admin WHERE username=%s AND password=%s", (username, password))
        admin = cursor.fetchone()

        if admin:
            session['role'] = 'admin'  # Set role as admin
            session['admin_id'] = admin[0]  # Store admin ID in session for later use
            return redirect(url_for('admin_dashboard'))  # Redirect to the admin dashboard
        else:
            return "Invalid username or password"

    return render_template('admin_login.html')


# Student Dashboard Route
@app.route('/student-dashboard')
def student_dashboard():
    if 'role' in session and session['role'] == 'student':
        return render_template('student_dashboard.html')
    return redirect(url_for('student_login'))

# Teacher Dashboard Route
@app.route('/teacher-dashboard')
def teacher_dashboard():
    if 'role' in session and session['role'] == 'teacher':
        return render_template('teacher_dashboard.html')
    return redirect(url_for('teacher_login'))

# Admin Dashboard Route
@app.route('/admin-dashboard')
def admin_dashboard():
    return render_template('admin_dashboard.html')

# Mark Attendance Route
@app.route('/mark-attendance', methods=['GET', 'POST'])
def mark_attendance():
    # Check if the user is a teacher or admin
    if 'role' in session and (session['role'] == 'teacher' or session['role'] == 'admin'):
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",  # Add your MySQL password
            database="cms_db"
        )
        cursor = conn.cursor()

        if request.method == 'POST':
            subject_id = request.form['subject_id']
            current_date = date.today()

            # Fetch students
            cursor.execute("SELECT id FROM students")
            students = cursor.fetchall()

            # Insert attendance for each student
            for student in students:
                student_id = student[0]
                attendance_status = request.form.get(f'attendance_status_{student_id}')

                if attendance_status:
                    cursor.execute(
                        "INSERT INTO attendance (student_id, subject_id, date, status) VALUES (%s, %s, %s, %s)",
                        (student_id, subject_id, current_date, attendance_status)
                    )

            conn.commit()  # Commit changes
            cursor.close()  # Close cursor
            conn.close()  # Close connection

            return redirect(url_for('mark_attendance'))

        # Fetch subjects and students for the form
        cursor.execute("SELECT id, subject_name FROM subjects")
        subjects = cursor.fetchall()

        cursor.execute("SELECT id, username FROM students")
        students = cursor.fetchall()

        cursor.close()
        conn.close()

        return render_template('mark_attendance.html', subjects=subjects, students=students)

    return redirect(url_for('admin_login'))




# Manage Assignments Route
@app.route('/manage-assignments', methods=['GET', 'POST'])
def manage_assignments():
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",  # Your MySQL password
        database="cms_db"
    )
    cursor = conn.cursor()

    # Fetch all subjects
    cursor.execute("SELECT * FROM subjects")
    subjects = cursor.fetchall()

    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        due_date = request.form['due_date']
        subject_id = request.form.get('subject_id')  # Use get() to avoid KeyError

        # Check if subject_id is provided
        if subject_id:
            cursor.execute(
                "INSERT INTO assignments (title, description, due_date, subject_id) VALUES (%s, %s, %s, %s)",
                (title, description, due_date, subject_id)
            )
            conn.commit()
        else:
            flash('Please select a subject.', 'error')  # Flash an error message

    # Fetch all assignments
    cursor.execute("SELECT * FROM assignments")
    assignments = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template('manage_assignments.html', assignments=assignments, subjects=subjects)




@app.route('/edit-assignment/<int:assignment_id>', methods=['GET', 'POST'])
def edit_assignment(assignment_id):
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",  # Your MySQL password
        database="cms_db"
    )
    cursor = conn.cursor()

    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        due_date = request.form['due_date']
        subject_id = request.form['subject_id']

        cursor.execute(
            "UPDATE assignments SET title=%s, description=%s, due_date=%s, subject_id=%s WHERE id=%s",
            (title, description, due_date, subject_id, assignment_id)
        )
        conn.commit()
        return redirect(url_for('manage_assignments'))

    # Fetch the assignment to edit
    cursor.execute("SELECT * FROM assignments WHERE id=%s", (assignment_id,))
    assignment = cursor.fetchone()

    # Fetch subjects for the dropdown
    cursor.execute("SELECT * FROM subjects")  # Ensure this is correct
    subjects = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template('edit_assignment.html', assignment=assignment, subjects=subjects)


@app.route('/delete-assignment/<int:assignment_id>')
def delete_assignment(assignment_id):
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",  # Your MySQL password
        database="cms_db"
    )
    cursor = conn.cursor()

    cursor.execute("DELETE FROM assignments WHERE id=%s", (assignment_id,))
    conn.commit()

    cursor.close()
    conn.close()

    return redirect(url_for('manage_assignments'))



# View Students Route
@app.route('/view-students')
def view_students():
    cursor.execute("""
        SELECT students.id, students.username, subjects.subject_name, attendance.status
        FROM students
        JOIN attendance ON students.id = attendance.student_id
        JOIN subjects ON attendance.subject_id = subjects.id;
    """)
    students = cursor.fetchall()
    return render_template('view_students.html', students=students)


@app.route('/view_attendance')
def view_attendance():
    if 'student_id' not in session:
        return redirect(url_for('login'))

    student_id = session['student_id']

    cursor = db.cursor()
    query = """
        select * from attendance;
    """
    cursor.execute(query, (student_id,))
    attendance_records = cursor.fetchall()
    cursor.close()

    return render_template('view_attendance.html', attendance_records=attendance_records)


# View Subjects Route
@app.route('/view_subjects', methods=['GET'])
def view_subjects():
    if 'role' in session and session['role'] == 'teacher':
        teacher_id = session['teacher_id']
        print(f"Fetching subjects for teacher ID: {teacher_id}")  # Debugging output
        cursor.execute("SELECT subject_name FROM subjects WHERE teacher_id = %s", (teacher_id,))
        subjects = cursor.fetchall()
        print(f"Fetched subjects: {subjects}")  # Debugging output
        return render_template('view_subjects.html', subjects=subjects)
    return redirect(url_for('teacher_login'))


# Teacher Classes Route
@app.route('/teacher-classes')
def teacher_classes():
    if 'role' in session and session['role'] == 'teacher':
        teacher_id = session['teacher_id']
        # Fetch subjects/classes assigned to the teacher
        cursor.execute("SELECT subject_name FROM subjects WHERE teacher_id = %s", (teacher_id,))
        classes = cursor.fetchall()  # Fetch subject names
        return render_template('teacher_classes.html', classes=classes)
    return redirect(url_for('teacher_login'))

# View Students Option in Teacher Dashboard
@app.route('/view-students-teacher')
def view_students_teacher():
    return redirect(url_for('view_students'))

# Logout Route
@app.route('/logout')
def logout():
    # Clear session data
    session.clear()
    return redirect(url_for('home'))

# View Assignments Route
@app.route('/view_assignments')
def view_assignments():
    cursor = db.cursor()
    try:
        cursor.execute("""
            SELECT
                a.title,
                a.description,
                s.subject_name AS subject_name,
                a.due_date
            FROM
                assignments a
            LEFT JOIN
                subjects s ON a.subject_id = s.id;
        """)
        assignments = cursor.fetchall()
    except Exception as e:
        print(f"Error fetching assignments: {e}")
        assignments = []  # Fallback to an empty list in case of error
    finally:
        cursor.close()

    print(assignments)  # Debug print to check fetched data
    return render_template('view_assignments.html', assignments=assignments)



def get_db_connection():
    try:
        connection = mysql.connector.connect(
            host='localhost',        # e.g., 'localhost'
            user='root',    # your MySQL username
            password='', # your MySQL password
            database='cms_db'  # your database name
        )
        if connection.is_connected():
            return connection
    except OSError as e:
        print(f"Error: {e}")
        return None
    
def fetch_subjects():
    connection = get_db_connection()
    subjects = []
    if connection:
        cursor = connection.cursor()
        cursor.execute("SELECT id, subject_name FROM subjects;")  # Adjust the query according to your table structure
        subjects = cursor.fetchall()  # Fetch all subjects
        cursor.close()
        connection.close()
    return subjects


def fetch_assignments(db):
    cursor = db.cursor()
    query = """
        SELECT
            a.title,
            a.description,
            s.subject_name,
            a.due_date
        FROM
            assignments a
        JOIN
            subjects s ON a.subject_id = s.id
        WHERE
            a.subject_id IS NOT NULL AND a.subject_id != 0;
    """
    cursor.execute(query)
    assignments = cursor.fetchall()
    cursor.close()  # Manually close the cursor
    return assignments

# Fetch the assignments
assignments = fetch_assignments(db)
print(assignments)

# Run the app
if __name__ == '__main__':
    app.run(debug=True)
    